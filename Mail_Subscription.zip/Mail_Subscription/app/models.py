from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django_quill.fields import QuillField


# Create your models here.
class MailListModel(models.Model):
    email = models.EmailField(unique=True)
    email_count = models.CharField(max_length=255, default=1, blank=True)
    last_campaign_name = models.CharField(max_length=255, default='None', blank=True)

    class Meta:
        verbose_name_plural = 'Mail List'

    def __str__(self):
        return self.email


class CampaignModel(models.Model):
    campaign_title = models.CharField(max_length=255, blank=False, unique=True)
    campaign_text = models.TextField()
    # campaign_text = QuillField()

    class Meta:
        verbose_name_plural = 'Campaign'

    def __str__(self):
        return self.campaign_title


# @receiver(post_save, sender=CampaignModel)
# def update_position(sender, instance, created, **kwargs):
#     quali = instance.qualification
#     member = instance.staff_member
#     # print(quali)
#     # print(member)
#     dictt = {
#         'None': 'None',
#         'PHD': 'Professor',
#         'MPhil': 'Lecturer',
#         'Masters': 'Asc.Lecturer',
#         'Bachelors': 'Lab.Asc',
#     }
#     pos = dictt.get(quali)
#     print(pos)
#     stf = StaffModel.objects.get(staff_id=member)
#     stf.position = pos
#     stf.save()
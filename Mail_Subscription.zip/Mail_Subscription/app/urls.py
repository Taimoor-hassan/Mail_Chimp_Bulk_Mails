from django.urls import path
from .views import *
urlpatterns = [
    path('', EmilSubscribeView.as_view(), name='home'),
    path('mail-list/', EmailListView.as_view(), name='mail-list'),
    path('campaign/', CampaignMessageView.as_view(), name='campaign'),
    path('campaign_rerun/<int:id>/', CampaignRerunidView, name='campaign_rerunid'),
    path('campaign_delete/<int:id>/', CampaignDeletedView, name='campaign_delete'),
    path('campaign_rerun/', CampaignRerunView.as_view(), name='campaign_rerun'),
    path('delete/<int:id>/', EmailDeleteView, name='delete_mail')
]

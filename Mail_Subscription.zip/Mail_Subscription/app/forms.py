from django import forms
from django.contrib.auth.forms import UserCreationForm

from .models import *


class EmailForm(forms.ModelForm):
    class Meta:
        model = MailListModel
        fields = ['email']
        widgets = {
            'email': forms.EmailInput(attrs={'class': 'form-control'})
        }


class ComapinForm(forms.ModelForm):
    class Meta:
        model = CampaignModel
        fields = ['campaign_title', 'campaign_text']
        widgets = {
            'campaign_title': forms.TextInput(attrs={'class': 'form-control'}),
            'campaign_text': forms.Textarea(attrs={'class': 'form-control'})
        }


# class SignupForm(UserCreationForm):
#     email = forms.EmailField(max_length=200, help_text='Required')
#
#     class Meta:
#         model = User
#         fields = ('username', 'email', 'password1', 'password2')

from django.contrib import admin
from .models import *


@admin.register(CampaignModel)
class CampaignAdmin(admin.ModelAdmin):
    pass


@admin.register(MailListModel)
class MailListAdmin(admin.ModelAdmin):
    pass

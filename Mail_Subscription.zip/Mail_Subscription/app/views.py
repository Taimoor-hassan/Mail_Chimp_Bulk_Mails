import schedule as schedule
from django.core.mail import send_mail
from django.db.models import F
from django.shortcuts import render, redirect
from django.views import View
from .forms import *
from .models import *
# import schedule
import time
from django.views.generic import ListView, FormView, TemplateView


class EmilSubscribeView(View):
    template = 'index.html'

    def get(self, request):
        form = EmailForm()
        data = {
            'form': form,
            'pageinfo': 'Email Subscribtion'
        }
        return render(request, self.template, data)

    def post(self, request):

        if request.method == 'POST':
            form = EmailForm(request.POST)
            if form.is_valid():
                client = form.cleaned_data['email']
                form.save()

                message = 'Thanks for Registering/Subscribing to our platform'
                subject = 'Subscription Conformation Mail'
                recipients = ['king.taimoor98.th@gmail.com', ]
                recipients.append(client)
                send_mail(subject, message, 'king.taimoor98.th@gmail.com', recipients)

                return redirect('home')
        else:
            form = EmailForm()

        return render(request, self.template, {'form': form})


class CampaignMessageView(View):
    template = 'campaign_message.html'

    def get(self, request):
        form = ComapinForm()
        data = {
            'form': form,
            'pageinfo': 'Run New Campaign'
        }
        return render(request, self.template, data)

    def post(self, request):
        if request.method == "POST":
            # try:
            form = ComapinForm(request.POST)
            if form.is_valid():
                recipients = MailListModel.objects.only('email')
                subject = form.cleaned_data['campaign_title']
                message = form.cleaned_data['campaign_text']
                form.save()
                from_email = 'king.taimoor98.th@gmail.com'
                send_mail(subject, message, from_email, recipients)
                str(MailListModel.objects.only('email_count').update(email_count=F('email_count') + 1))
                str(MailListModel.objects.only('last_campaign_name').update(
                    last_campaign_name=subject))

                return redirect('campaign')
        # except:
        #     recipients = MailListModel.objects.only('email')
        #     compain = CompainModel.objects.get(pk=id)
        #     subject = compain.compain_title
        #     message = compain.compain_text
        #     from_email = 'king.taimoor98.th@gmail.com'
        #     send_mail(subject, message, from_email, recipients)
        #     return redirect('compain')

        else:
            form = ComapinForm()
        return render(request, 'campaign_message.html', {'form': form})


class EmailListView(View):
    template = 'email-list.html'

    def get(self, request):
        mail_list = MailListModel.objects.all()
        data = {
            'mail_list': mail_list,
            'pageinfo': 'Subscribed Emails List'
        }
        return render(request, self.template, data)


class CampaignRerunView(View):

    def get(self, request):
        previous_campaign = CampaignModel.objects.all()
        data = {
            'previous_campaign': previous_campaign,
            'pageinfo': 'Previous Campaigns'
        }
        return render(request, 'previous_campaigns.html', data)

    def post(self, request):
        recipients = MailListModel.objects.only('email')
        campaign = CampaignModel.objects.get(pk=request.data.get('id'))
        subject = campaign.campaign_title
        message = campaign.campaign_text
        from_email = 'king.taimoor98.th@gmail.com'
        send_mail(subject, message, from_email, recipients)
        str(MailListModel.objects.only('email_count').update(email_count=F('email_count') + 1))
        str(MailListModel.objects.only('last_campaign_name').update(
            last_campaign_name=subject))

        return redirect('campaign_rerun')


def CampaignRerunidView(request, id):
    if request.method == 'POST':
        recipients = MailListModel.objects.only('email')
        campaign = CampaignModel.objects.get(pk=id)
        subject = campaign.campaign_title
        message = campaign.campaign_text
        from_email = 'king.taimoor98.th@gmail.com'
        send_mail(subject, message, from_email, recipients)
        str(MailListModel.objects.only('email_count').update(email_count=F('email_count') + 1))
        str(MailListModel.objects.only('last_campaign_name').update(
            last_campaign_name=subject))

        return redirect('campaign_rerun')


def CampaignDeletedView(request, id):
    if request.method == 'POST':
        campaign = CampaignModel.objects.get(pk=id)
        campaign.delete()
        return redirect('campaign_rerun')


def EmailDeleteView(request, id):
    if request.method == 'POST':
        email = MailListModel.objects.get(pk=id)
        email.delete()
        return redirect('mail-list')

# def job():
#     print("I'm working...")
#
#
# schedule.every(.5).minutes.do(job)
# # schedule.every().hour.do(job)
# # schedule.every().day.at("10:30").do(job)
# # schedule.every().monday.do(job)
# # schedule.every().wednesday.at("13:15").do(job)
#
# while True:
#     schedule.run_pending()
#     time.sleep(1)

# class EmilSubscribeView(View):
#     template = 'index.html'
#
#     def get(self, request):
#         form = EmailForm()
#         return render(request, self.template, {'form': form})
#
#     def post(self, request):
#
#         if request.method == 'POST':
#             form = EmailForm(request.POST)
#             if form.is_valid():
#                 client = form.cleaned_data['email']
#                 form.save()
#
#                 message = 'Thanks for Registering/Subscribing to our platform'
#                 subject = 'Subscription Conformation Mail'
#                 recipients = ['king.taimoor98.th@gmail.com']
#                 recipients.append(client)
#                 send_mail(subject, message, client, recipients)
#
#                 # subject, from_email, to = 'hello', 'king.taimoor98.th@gmail.com', client
#                 # text_content = 'This is an important message.'
#                 # html_content = '<p>This is an <strong>important</strong> message.</p>'
#                 # msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
#                 # msg.attach_alternative(html_content, "text/html")
#                 # msg.send()
#
#                 return redirect('home')
#         else:
#             form = EmailForm()
#
#         return render(request, self.template, {'form': form})


# def signup(request):
#     if request.method == 'POST':
#         form = SignupForm(request.POST)
#         if form.is_valid():
#             user = form.save(commit=False)
#             user.is_active = False
#             user.save()
#             current_site = get_current_site(request)
#             mail_subject = 'Activate your blog account.'
#             message = render_to_string('acc_active_email.html', {
#                 'user': user,
#                 'domain': current_site.domain,
#                 'uid':urlsafe_base64_encode(force_bytes(user.pk)),
#                 'token':account_activation_token.make_token(user),
#             })
#             to_email = form.cleaned_data.get('email')
#             email = EmailMessage(
#                         mail_subject, message, to=[to_email]
#             )
#             email.send()
#             return HttpResponse('Please confirm your email address to complete the registration')
#     else:
#         form = SignupForm()
#     return render(request, 'signup.html', {'form': form})

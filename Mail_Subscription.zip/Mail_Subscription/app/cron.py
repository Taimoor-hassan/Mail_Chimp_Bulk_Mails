from django.core.mail import send_mail
from django.db.models import F

from .models import *


def my_cron_job():
    # your functionality goes here
    recipients = MailListModel.objects.only('email')
    campaign = CampaignModel.objects.filter(campaign_title='Monthly Campaign satisfaction mail')
    subject = campaign.campaign_title
    message = campaign.campaign_text
    from_email = 'king.taimoor98.th@gmail.com'
    send_mail(subject, message, from_email, recipients)
    str(MailListModel.objects.only('email_count').update(email_count=F('email_count') + 1))

    print('it runs')

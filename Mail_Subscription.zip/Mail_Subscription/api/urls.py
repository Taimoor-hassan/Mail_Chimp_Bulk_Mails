from django.urls import path
from .views import *
urlpatterns = [
    path('api_email/', MailListAPIView.as_view(), name='mail_api'),
    path('api_cmp/', CampaignAPIView.as_view(), name='campaign_api'),
    path('api_cmprr/', CampaignRerunAPIView.as_view(), name='campaignrerun_api'),
]

from app.models import *
from rest_framework import serializers


class MailListSerializer(serializers.ModelSerializer):
    class Meta:
        model = MailListModel
        fields = '__all__'


class CampaignSerializer(serializers.ModelSerializer):
    class Meta:
        model = CampaignModel
        fields = '__all__'


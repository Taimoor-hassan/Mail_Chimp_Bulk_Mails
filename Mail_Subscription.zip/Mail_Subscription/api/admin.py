from django.contrib import admin
from app.models import *

# Register your models here.
admin.site.unregister(CampaignModel)
admin.site.unregister(MailListModel)


@admin.register(CampaignModel)
class CampaignAdmin(admin.ModelAdmin):
    pass


@admin.register(MailListModel)
class MailListAdmin(admin.ModelAdmin):
    pass

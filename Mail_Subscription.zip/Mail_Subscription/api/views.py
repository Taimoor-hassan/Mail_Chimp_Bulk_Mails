from django.core.mail import send_mail
from django.db.models import F
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from app.models import *
from .serializers import *


class MailListAPIView(APIView):
    def get(self, request):
        maillist = MailListModel.objects.all()
        serializer = MailListSerializer(maillist, many=True)

        return Response({
            'success': True,
            'message': 'Your are shown the request of GET data',
            'user_data': serializer.data
        })

    def post(self, request):

        if request.data.get('email') != None:
            serializer = MailListSerializer(data=request.data)
            if serializer.is_valid():
                # client = serializer.cleaned_data['email']
                client = request.data.get('email')
                serializer.save()

                message = 'Thanks for Registering/Subscribing to our platform'
                subject = 'Subscription Conformation Mail'
                recipients = ['king.taimoor98.th@gmail.com', ]
                recipients.append(client)
                send_mail(subject, message, 'king.taimoor98.th@gmail.com', recipients)

                try:
                    return Response({
                        'success': True,
                        'message': 'Your Mail_List was successful of below JSON',
                        'data': serializer.data,
                    }, status=status.HTTP_200_OK)
                except:
                    return Response({
                        'success': False,
                        'message': 'Provides data was hot correct',
                        'data': serializer.data,
                    })

    def delete(self, request):

        if request.data.get('id') != None:
            if request.data.get('email') != None:
                person = MailListModel.objects.get(pk=request.data.get('id'))
                person.delete()
                return Response({
                    'success': True,
                    'message': 'Deleted successfully',
                }, status=status.HTTP_200_OK)


class CampaignAPIView(APIView):

    def get(self, request):
        Campaiglist = CampaignModel.objects.all()
        serializer = CampaignSerializer(Campaiglist, many=True)

        return Response({
            'success': True,
            'message': 'Your are shown the request of GET data',
            'user_data': serializer.data
        })

    def post(self, request):

        if request.data.get('campaign_title') != None:
            serializer = CampaignSerializer(data=request.data)
            if serializer.is_valid():
                recipients = MailListModel.objects.only('email')
                subject = request.data.get('campaign_title')
                message = request.data.get('campaign_text')
                serializer.save()
                from_email = 'king.taimoor98.th@gmail.com'
                send_mail(subject, message, from_email, recipients)
                str(MailListModel.objects.only('email_count').update(email_count=F('email_count') + 1))
                str(MailListModel.objects.only('last_campaign_name').update(
                    last_campaign_name=subject))

                try:
                    return Response({
                        'success': True,
                        'message': 'Your Campaign_List was successful of below JSON',
                        'data': serializer.data,
                    }, status=status.HTTP_200_OK)
                except:
                    return Response({
                        'success': False,
                        'message': 'Provides data was not correct'
                    })

    def delete(self, request):

        if request.data.get('id') != None:
            if request.data.get('campaign_title') != None:
                campaign = CampaignModel.objects.get(pk=request.data.get('id'))
                campaign.delete()
                return Response({
                    'success': True,
                    'message': 'Deleted successfully',
                }, status=status.HTTP_200_OK)


class CampaignRerunAPIView(APIView):

    # def get(self, request):
    #     Campaiglist = CampaignModel.objects.all()
    #     serializer = CampaignSerializer(Campaiglist, many=True)
    #
    #     return Response({
    #         'success': True,
    #         'message': 'Your are shown the request of GET data',
    #         'user_data': serializer.data
    #     })

    def post(self, request):

        if request.data.get('id') != None:
            # if serializer.is_valid():
            recipients = MailListModel.objects.only('email')
            campaign = CampaignModel.objects.get(pk=request.data.get('id'))
            subject = campaign.campaign_title
            message = campaign.campaign_text
            from_email = 'king.taimoor98.th@gmail.com'
            send_mail(subject, message, from_email, recipients)
            str(MailListModel.objects.only('email_count').update(email_count=F('email_count') + 1))
            str(MailListModel.objects.only('last_campaign_name').update(
                last_campaign_name=subject))

            try:
                return Response({
                    'success': True,
                    'message': 'Your Campaign_List was successful of below JSON',
                    'data': subject,
                }, status=status.HTTP_200_OK)
            except:
                return Response({
                    'success': False,
                    'message': 'Provides data was not correct'
                })
